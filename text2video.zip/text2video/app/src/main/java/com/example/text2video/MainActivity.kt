package com.example.text2video

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var showSettings by remember { mutableStateOf(state.serverUrl.isBlank()) }
    var url by remember { mutableStateOf(state.serverUrl) }
    var key by remember { mutableStateOf(state.apiKey) }
    val working = state.phase == Phase.Working

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Text2Video", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Describe a scene. Your server makes the video and this app plays it.",
            style = MaterialTheme.typography.bodyMedium,
        )

        OutlinedTextField(
            value = state.prompt,
            onValueChange = vm::setPrompt,
            label = { Text("Prompt") },
            placeholder = { Text("A paper boat drifts down a rainy street at dusk, cinematic") },
            minLines = 3,
            enabled = !working,
            modifier = Modifier.fillMaxWidth(),
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(2, 4, 6).forEach { s ->
                FilterChip(
                    selected = state.seconds == s,
                    onClick = { vm.setSeconds(s) },
                    enabled = !working,
                    label = { Text("$s s") },
                )
            }
        }

        if (working) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Text(state.message, style = MaterialTheme.typography.bodyMedium)
            OutlinedButton(onClick = vm::cancel) { Text("Stop waiting") }
        } else {
            Button(onClick = vm::generate, modifier = Modifier.fillMaxWidth()) {
                Text("Make video")
            }
        }

        if (state.phase == Phase.Failed) {
            Text(state.message, color = MaterialTheme.colorScheme.error)
        }

        state.videoPath?.let { path ->
            VideoPlayer(path)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = vm::saveToGallery) { Text("Save to gallery") }
            }
            state.savedNote?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }

        TextButton(onClick = { showSettings = !showSettings }) {
            Text(if (showSettings) "Hide settings" else "Settings")
        }
        if (showSettings) {
            OutlinedTextField(
                value = url,
                onValueChange = { url = it; vm.setServer(it, key) },
                label = { Text("Server address") },
                placeholder = { Text("http://192.168.1.20:8000") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; vm.setServer(url, it) },
                label = { Text("API key (optional)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
fun VideoPlayer(path: String) {
    val context = LocalContext.current
    val player = remember(path) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))))
            repeatMode = Player.REPEAT_MODE_ONE
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { PlayerView(it).apply { this.player = player } },
        update = { it.player = player },
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(704f / 480f),
    )
}
