package com.example.text2video

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

enum class Phase { Idle, Working, Done, Failed }

data class UiState(
    val serverUrl: String = "",
    val apiKey: String = "",
    val prompt: String = "",
    val seconds: Int = 4,
    val phase: Phase = Phase.Idle,
    val message: String = "",
    val videoPath: String? = null,
    val savedNote: String? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(
        UiState(
            serverUrl = prefs.getString("url", "") ?: "",
            apiKey = prefs.getString("key", "") ?: "",
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var job: Job? = null

    fun setPrompt(value: String) = _state.update { it.copy(prompt = value) }

    fun setSeconds(value: Int) = _state.update { it.copy(seconds = value) }

    fun setServer(url: String, key: String) {
        prefs.edit().putString("url", url).putString("key", key).apply()
        _state.update { it.copy(serverUrl = url, apiKey = key) }
    }

    private fun message(text: String) = _state.update { it.copy(message = text) }

    private fun fail(text: String) =
        _state.update { it.copy(phase = Phase.Failed, message = text) }

    fun cancel() {
        job?.cancel()
    }

    fun generate() {
        val current = _state.value
        if (current.phase == Phase.Working) return
        if (current.prompt.isBlank()) return fail("Describe the video first.")
        if (current.serverUrl.isBlank()) return fail("Add your server address in Settings first.")

        job = viewModelScope.launch {
            _state.update {
                it.copy(phase = Phase.Working, message = "Sending your prompt...", videoPath = null, savedNote = null)
            }
            try {
                val api = VideoApi(current.serverUrl, current.apiKey)
                val id = api.submit(current.prompt.trim(), current.seconds)
                val started = System.currentTimeMillis()
                while (true) {
                    delay(3000)
                    if (System.currentTimeMillis() - started > 30 * 60 * 1000) {
                        throw ApiException("Timed out after 30 minutes. Check the server.")
                    }
                    val status = api.status(id)
                    when (status.state) {
                        "queued" -> message("Waiting in the queue...")
                        "running" -> message("Generating. This can take several minutes...")
                        "done" -> break
                        "error" -> throw ApiException(status.detail ?: "The server could not make this video.")
                    }
                }
                message("Downloading the video...")
                val file = File(getApplication<Application>().cacheDir, "out_$id.mp4")
                api.download(id, file)
                _state.update { it.copy(phase = Phase.Done, message = "", videoPath = file.absolutePath) }
            } catch (e: CancellationException) {
                _state.update { it.copy(phase = Phase.Idle, message = "") }
                throw e
            } catch (e: ApiException) {
                fail(e.message ?: "Something went wrong.")
            } catch (e: IllegalArgumentException) {
                fail("The server address is not valid. Use a form like http://192.168.1.20:8000")
            } catch (e: IOException) {
                fail("Could not reach the server. Check the address and that your phone can reach it.")
            } catch (e: Exception) {
                fail(e.message ?: "Something went wrong.")
            }
        }
    }

    fun saveToGallery() {
        val path = _state.value.videoPath ?: return
        viewModelScope.launch {
            val note = withContext(Dispatchers.IO) {
                try {
                    val resolver = getApplication<Application>().contentResolver
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "text2video_${System.currentTimeMillis()}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Text2Video")
                    }
                    val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                        ?: return@withContext "Could not create the file in your gallery."
                    resolver.openOutputStream(uri)?.use { out ->
                        File(path).inputStream().use { it.copyTo(out) }
                    }
                    "Saved to Movies/Text2Video."
                } catch (e: Exception) {
                    "Could not save the video: ${e.message}"
                }
            }
            _state.update { it.copy(savedNote = note) }
        }
    }
}
