package com.example.text2video

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class ApiException(message: String) : Exception(message)

data class JobStatus(val state: String, val detail: String?)

/** Talks to the generation server in /server. Three calls: submit, status, download. */
class VideoApi(baseUrl: String, private val apiKey: String) {
    private val base = baseUrl.trim().trimEnd('/')

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    private fun request(path: String): Request.Builder {
        val builder = Request.Builder().url("$base$path")
        if (apiKey.isNotBlank()) builder.header("X-API-Key", apiKey)
        return builder
    }

    private fun errorOf(code: Int, body: String): String {
        val detail = try {
            JSONObject(body).opt("detail")?.toString()
        } catch (e: Exception) {
            null
        }
        return when {
            code == 401 -> "The API key was not accepted. Check it in Settings."
            code == 429 -> detail ?: "The server queue is full. Try again in a few minutes."
            detail != null -> detail
            else -> "The server answered with an error ($code)."
        }
    }

    suspend fun submit(prompt: String, seconds: Int): String = withContext(Dispatchers.IO) {
        val json = JSONObject().put("prompt", prompt).put("seconds", seconds).toString()
        val body = json.toRequestBody("application/json".toMediaType())
        client.newCall(request("/generate").post(body).build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw ApiException(errorOf(response.code, text))
            JSONObject(text).getString("id")
        }
    }

    suspend fun status(id: String): JobStatus = withContext(Dispatchers.IO) {
        client.newCall(request("/status/$id").get().build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw ApiException(errorOf(response.code, text))
            val json = JSONObject(text)
            JobStatus(json.getString("state"), json.optString("detail").ifBlank { null })
        }
    }

    suspend fun download(id: String, target: File) = withContext(Dispatchers.IO) {
        client.newCall(request("/video/$id").get().build()).execute().use { response ->
            if (!response.isSuccessful) {
                throw ApiException(errorOf(response.code, response.body?.string().orEmpty()))
            }
            val source = response.body ?: throw ApiException("The server sent an empty video.")
            source.byteStream().use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
        }
    }
}
