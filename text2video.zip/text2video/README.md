# Text2Video

An Android app that turns a text prompt into a short video. Free and open source (use any license you like, the code here is yours).

A phone cannot run a video model, so the project has two parts:

- `app/` is the Android app (Kotlin, Jetpack Compose). It sends your prompt to a server, waits, downloads the video, plays it and can save it to your gallery.
- `server/` is a small Python server that runs an open-source model (LTX-Video by default) on a GPU you control.

The app needs Android 10 or newer.

## 1. Run the server

You need a computer with an NVIDIA GPU and Python 3.10+. A GPU with about 16 GB of memory is a safe starting point.

```bash
cd server
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
API_KEY=choose-a-secret uvicorn app:app --host 0.0.0.0 --port 8000
```

The first video downloads the model weights and is slow. After that a short clip takes a few minutes, depending on your GPU.

Settings you can change with environment variables: `MODEL_ID`, `WIDTH`, `HEIGHT` (both divisible by 32), `STEPS` (fewer is faster, lower quality), `MAX_SECONDS`, `OFFLOAD=0` (faster but needs more GPU memory).

Reaching it from your phone:

- Same Wi-Fi: use `http://<your-computer-ip>:8000` in the app.
- From anywhere: put the server behind an https tunnel or reverse proxy and use that https address. Always set `API_KEY` when the server is reachable from the internet.

## 2. Build the APK

**Option A: Android Studio.** Open this folder, let Gradle sync, then Build > Build APK(s). The file is at `app/build/outputs/apk/debug/app-debug.apk`.

**Option B: free GitHub build, no Android Studio.** Push this folder to a GitHub repository, open the Actions tab, run "Build APK", then download the `text2video-debug-apk` artifact.

Copy the APK to your phone and install it (Android asks you to allow installs from your file manager or browser). It is a debug-signed build, fine for personal use. Publishing to Google Play needs a release signing key.

## 3. Use it

Open the app, tap Settings, enter the server address and your API key, then type a prompt and tap Make video.

## Notes

- The app allows plain `http://` so it can talk to a server on your home network. Use https for anything on the internet.
- Generated videos on the server are deleted after 24 hours (`KEEP_HOURS`).
- Other open models (CogVideoX, Wan) can be swapped into `server/app.py`; each needs its own diffusers pipeline and more GPU memory.
