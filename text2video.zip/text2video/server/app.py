"""Text-to-video server for the Text2Video Android app.

Runs an open-source model (LTX-Video by default) on your own GPU and exposes three calls:
  POST /generate        {"prompt": "...", "seconds": 4}  ->  {"id": "..."}
  GET  /status/{id}     ->  {"state": "queued|running|done|error", "detail": "..."}
  GET  /video/{id}      ->  the finished .mp4

Start it with:  uvicorn app:app --host 0.0.0.0 --port 8000
"""
import os
import queue
import secrets
import threading
import time
import traceback
import uuid
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

API_KEY = os.environ.get("API_KEY", "")
MODEL_ID = os.environ.get("MODEL_ID", "Lightricks/LTX-Video")
WIDTH = int(os.environ.get("WIDTH", "704"))      # must be divisible by 32
HEIGHT = int(os.environ.get("HEIGHT", "480"))    # must be divisible by 32
STEPS = int(os.environ.get("STEPS", "30"))       # the model card example uses 50; fewer is faster
FPS = 24
MAX_SECONDS = int(os.environ.get("MAX_SECONDS", "6"))
MAX_QUEUE = int(os.environ.get("MAX_QUEUE", "5"))
KEEP_HOURS = int(os.environ.get("KEEP_HOURS", "24"))
OFFLOAD = os.environ.get("OFFLOAD", "1") == "1"  # 1 = lower GPU memory, slower
OUT_DIR = Path(os.environ.get("OUT_DIR", "outputs"))
OUT_DIR.mkdir(parents=True, exist_ok=True)

NEGATIVE = "worst quality, inconsistent motion, blurry, jittery, distorted"

app = FastAPI(title="Text2Video server")
jobs: dict[str, dict] = {}
pending: "queue.Queue[str]" = queue.Queue()


def check_key(x_api_key: str = Header(default="")) -> None:
    if API_KEY and not secrets.compare_digest(x_api_key, API_KEY):
        raise HTTPException(status_code=401, detail="Invalid API key")


class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=1000)
    seconds: int = Field(default=4, ge=1, le=60)


def load_pipeline():
    import torch
    from diffusers import LTXPipeline

    pipe = LTXPipeline.from_pretrained(MODEL_ID, torch_dtype=torch.bfloat16)
    if OFFLOAD:
        pipe.enable_model_cpu_offload()
    else:
        pipe.to("cuda")
    return pipe


def worker() -> None:
    from diffusers.utils import export_to_video

    pipe = None
    while True:
        job_id = pending.get()
        job = jobs[job_id]
        job["state"] = "running"
        try:
            if pipe is None:
                pipe = load_pipeline()
            seconds = min(job["seconds"], MAX_SECONDS)
            frames = (seconds * FPS // 8) * 8 + 1  # the model expects 8k + 1 frames
            result = pipe(
                prompt=job["prompt"],
                negative_prompt=NEGATIVE,
                width=WIDTH,
                height=HEIGHT,
                num_frames=frames,
                num_inference_steps=STEPS,
            ).frames[0]
            path = OUT_DIR / f"{job_id}.mp4"
            export_to_video(result, str(path), fps=FPS)
            job["path"] = str(path)
            job["state"] = "done"
        except Exception as exc:  # report to the app instead of dying
            traceback.print_exc()
            job["state"] = "error"
            job["detail"] = f"{type(exc).__name__}: {exc}"[:300]


def cleanup_old_files() -> None:
    limit = time.time() - KEEP_HOURS * 3600
    for f in OUT_DIR.glob("*.mp4"):
        try:
            if f.stat().st_mtime < limit:
                f.unlink()
        except OSError:
            pass


threading.Thread(target=worker, daemon=True).start()


@app.get("/health")
def health():
    return {"ok": True, "model": MODEL_ID}


@app.post("/generate", dependencies=[Depends(check_key)])
def generate(req: GenerateRequest):
    if pending.qsize() >= MAX_QUEUE:
        raise HTTPException(status_code=429, detail="The server queue is full. Try again in a few minutes.")
    cleanup_old_files()
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"state": "queued", "prompt": req.prompt.strip(), "seconds": req.seconds, "detail": ""}
    pending.put(job_id)
    return {"id": job_id}


@app.get("/status/{job_id}", dependencies=[Depends(check_key)])
def status(job_id: str):
    job = jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Unknown job")
    return {"state": job["state"], "detail": job.get("detail", "")}


@app.get("/video/{job_id}", dependencies=[Depends(check_key)])
def video(job_id: str):
    job = jobs.get(job_id)
    if job is None or job.get("state") != "done" or not Path(job["path"]).exists():
        raise HTTPException(status_code=404, detail="Video not ready or already removed")
    return FileResponse(job["path"], media_type="video/mp4", filename=f"{job_id}.mp4")
